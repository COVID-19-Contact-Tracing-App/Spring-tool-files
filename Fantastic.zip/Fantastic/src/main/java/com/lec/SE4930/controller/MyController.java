package com.lec.SE4930.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lec.SE4930.domain.Mail;
import com.lec.SE4930.domain.User;
import com.lec.SE4930.service.MailService;
import com.lec.SE4930.service.UserService;


@Controller
public class MyController {

	@Autowired UserService userService;
	@Autowired MailService mailService;
	
	boolean loginstatus = false;
	
	@RequestMapping(value = "/home")
	public String home() {

		System.out.println("home.jsp");
		return "register";
	}
	
	
	@RequestMapping(value = "/support")
	public String support() {

		System.out.println("support.jsp");
		
		sendemail();
		
		return "support";
	}
	
	
	@PostMapping(value = "/email")
	public String email(String title, String msg ) {

		Mail mail = new Mail();
		mail.setMailFrom("jec72280@ucmo.edu");
		mail.setMailTo("jec72280@ucmo.edu");
		mail.setMailSubject(title);
		mail.setMailContent(msg);
		
		mailService.sendEmail(mail);
		
		
		return "support";
	}
	
	

	public void sendemail() {

		Mail mail = new Mail();
		mail.setMailFrom("jec72280@ucmo.edu");
		mail.setMailTo("jec72280@ucmo.edu");
		mail.setMailSubject("Test");
		mail.setMailContent("Covid warning message");
		
		mailService.sendEmail(mail);
	
	}
	
	
	
	@RequestMapping(value = "/create_account")
	public String MoveToRegister() {

		System.out.println("home.jsp");
		return "register";
	}
	
	
	@RequestMapping(value = "/alogin")
	public String alogin(Model model, String name, String password) {

		System.out.println(name);
		System.out.println("Password" + password); 
		
		User user = userService.getUser(name);
		
		
		System.out.println("test");
		
		String dbPassword = user.getPassword();
		
		if(password.equals(dbPassword)) {
			
			loginstatus = true;
		}
		
		
		
		model.addAttribute("loginS", loginstatus);
		model.addAttribute("userdata", user);
		
		
		return "main_page";
	}
	
	
	
	
	@RequestMapping(value = "/loginpage")
	public String hello() {
		
		System.out.println("TEst");
		return "log_in_page";
	}
	
	
	@RequestMapping(value = "/login_page")
	public String login() {
		
		return "log_in_page";
	}
	
	
	@RequestMapping(value = "/create")
	public String register(String userid, String name, String email, String password) {
		
		System.out.println("userid " + userid);
		System.out.println("password " +password);
		System.out.println("name " + name);
		System.out.println("email " + email);
		
		User user = new User();
		user.setUserid(userid);
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		
		userService.join(user);
		
		
		
		return "log_in_page";
	}
	
	
	
	
	@RequestMapping(value = "/")
	public String mainpage() {
		
		return "main_page";
	}
	
	
}
