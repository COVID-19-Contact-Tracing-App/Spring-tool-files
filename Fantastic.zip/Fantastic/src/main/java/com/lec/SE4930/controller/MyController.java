package com.lec.SE4930.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.lec.SE4930.domain.User;
import com.lec.SE4930.service.UserService;


@Controller
public class MyController {

	@Autowired UserService userService;
	
	
	
	@RequestMapping(value = "/")
	public String home() {

		System.out.println("home.jsp");
		return "register";
	}
	
	
	@RequestMapping(value = "/loginpage")
	public String hello() {
		
		System.out.println("TEst");
		return "log_in_page";
	}
	
	
	@RequestMapping(value = "/login_page")
	public String login() {
		
		return "log_in_page";
	}
	
	
	@RequestMapping(value = "/create")
	public String register(String userid, String name, String email, String password) {
		
		System.out.println("userid " + userid);
		System.out.println("password " +password);
		System.out.println("name " + name);
		System.out.println("email " + email);
		
		User user = new User();
		user.setUserid(userid);
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		
		userService.join(user);
		
		
		
		return "log_in_page";
	}
	
	
	
	
	@RequestMapping(value = "/main_page")
	public String mainpage() {
		
		return "main_page";
	}
	
	
}
