package com.lec.SE4930.service;

import com.lec.SE4930.domain.Mail;

public interface MailService {
    public void sendEmail(Mail mail);
}
