package com.lec.SE4930.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lec.SE4930.domain.User;
import com.lec.SE4930.repository.UserRepository;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	
	public long join(User user) {
		

		userRepository.save(user);
		
		return user.getId();
	}
	
	//jsp   >    Mycontroller >    join     > save     > mysql
 	
}
