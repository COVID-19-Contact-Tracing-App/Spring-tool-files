package com.lec.SE4930.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.lec.SE4930.domain.User;

@Repository
public class UserRepository {

	
	@PersistenceContext
	private EntityManager em;
	
	public void save(User user) {
		
		em.persist(user);
		
		
	}
	
	
}
