package com.lec.SE4930;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FantasticApplicationTests {

	@Test
	void contextLoads() {
	}

}
